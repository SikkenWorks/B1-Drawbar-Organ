**How to use it:**

1. Fully extract the ZIP.
2. Connect the FM1 in OCT− mode.
3. Open **START-RECOVERY.bat** and accept the administrator prompt.
4. Choose **2** and select the original **V15 `.fwsc`** file.
5. Once the tool has completed successfully, manually restart your FM1.