"""Windows WL82 recovery launcher. Hardware access belongs to the bundled upstream tool."""
from pathlib import Path
import ctypes, os, subprocess, sys, venv
ROOT=Path(__file__).resolve().parent
TOOL=ROOT/'vendor'/'unbricker'/'fm1_unbrick.py'
def invoke(python,*args):
    return subprocess.run([str(python),str(TOOL),*map(str,args)],cwd=ROOT).returncode

def main():
    if sys.platform!='win32':
        print('This launcher requires Windows. No device has been opened.');return 2
    if not ctypes.windll.shell32.IsUserAnAdmin():
        result=ctypes.windll.shell32.ShellExecuteW(None,'runas',sys.executable,subprocess.list2cmdline([str(Path(__file__).resolve())]),str(ROOT),1)
        if result<=32:print('Administrator access was not granted. Nothing written.');return 1
        return 0
    os.chdir(ROOT)
    python=ROOT/'runtime'/'Scripts'/'python.exe'
    if not python.exists():
        print('Creating a private Python environment in this folder...')
        venv.EnvBuilder(with_pip=True).create(ROOT/'runtime')
    print('\nFM1 WL82 USB RECOVERY v1.3\nUses the Windows disk driver. No MIDI selection or driver replacement.\n')
    print('1 = Detect only (no flash writes)\n2 = Restore verified official V15\nAny other key = Exit')
    choice=input('Choose: ').strip()
    if choice=='1':return invoke(python,'find')
    if choice!='2':return 0
    # Choose and validate the package before setup or opening any physical disk.
    import tkinter as tk
    from tkinter import filedialog
    window=tk.Tk();window.withdraw();window.attributes('-topmost',True)
    path=filedialog.askopenfilename(parent=window,title='Select the original official V15 FM-1.fwsc',filetypes=[('FM1 firmware','*.fwsc')]);window.destroy()
    if not path:print('Cancelled. Nothing written.');return 0
    if invoke(python,'extract',path,ROOT/'verified-v15-app.bin','--verify-v15'):return 1
    print('Preparing the pinned WL82 loader and dependencies. Internet required on first setup.')
    if invoke(python,'setup'):return 1
    print('The recovery tool will check the chip, back up flash twice and ask you to type WRITE.')
    # No --yes, --i-know, forced device path or full-flash writes.
    result=invoke(python,'restore',path,'--verify-v15')
    print('Tool exit code:',result)
    if result==0:print('Restore verified. Follow the restart instructions above.')
    elif result==3:print('WRITE VERIFICATION FAILED. Keep the FM1 powered. Preserve the logs and backup.')
    else:print('Stopped. Read the error above; no successful restore is confirmed.')
    return result
if __name__=='__main__':
    try:code=main()
    except Exception as exc:print('Recovery stopped:',exc);code=1
    if sys.platform=='win32' and ctypes.windll.shell32.IsUserAnAdmin():input('\nPress Enter to close...')
    raise SystemExit(code)
