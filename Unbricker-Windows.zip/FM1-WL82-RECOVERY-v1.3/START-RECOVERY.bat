@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import sys; assert sys.version_info >= (3,9)" >nul 2>&1
if not errorlevel 1 (
 py -3 recovery_windows.py
 goto done
)
python -c "import sys; assert sys.version_info >= (3,9)" >nul 2>&1
if not errorlevel 1 (
 python recovery_windows.py
 goto done
)
echo Python 3.9 or newer is required. Install Python from https://www.python.org/downloads/windows/
echo Then run this file again.
:done
pause
